# Design System — Vai Ter Forró!

_Vai Ter Forró! é a marca pública do site; o Movimento Livre de Forró é a
iniciativa que o mantém — ver nota em ROADMAP.md._

Este documento descreve os tokens e componentes já implementados em
`css/tokens.css` e `css/styles.css`. Não é um sistema à parte — é a leitura
organizada do que já existe no CSS, para qualquer pessoa (ou eu, no futuro)
conseguir reutilizar sem reabrir todos os arquivos.

## Princípio

Poucas cores, hierarquia clara, muito espaço em branco. Verde-pinha é a cor
de ação (botões, links, header). **Terracota é reservada exclusivamente para
o marcador "acontecendo hoje"** — nunca vira cor de botão genérica. Isso é
proposital: quando o terracota aparece, o usuário aprende a associar
"algo está rolando agora", e isso perde força se a cor for usada em qualquer
lugar.

## Cores (`css/tokens.css`)

| Token | Uso |
|---|---|
| `--ink` | Texto principal |
| `--ink-soft` | Texto secundário (parágrafos de apoio) |
| `--muted` | Metadados (datas, endereços) |
| `--paper` | Fundo da página |
| `--surface` | Fundo de cards e superfícies elevadas |
| `--sand` / `--sand-line` | Bordas e divisores |
| `--pine` / `--pine-strong` | Cor primária de ação (botões, links ativos, header) |
| `--pine-tint` | Fundo suave para blocos de destaque (ex. "Sobre o Movimento") |
| `--clay` | Reservada para o marcador "Hoje" — não usar em outros contextos |
| `--clay-tint` | Reservada para variações futuras do marcador de destaque |

## Tipografia

- **Display** (`--font-display`, Fraunces): títulos, `h1`–`h3`, nomes de evento nos cards.
- **Corpo/UI** (`--font-body`, Work Sans): texto corrido, botões, labels, filtros.
- Escala: `--text-xs` (12px) até `--text-4xl` (48px), sempre via variável — nunca `px` direto no CSS de componente.

## Espaçamento

Grid de 8px: `--sp-1` (4px) até `--sp-9` (96px). Qualquer margem/padding novo deve usar uma dessas variáveis.

## Componentes

### Botões (`.btn`)
- `.btn-primary` — ação principal (verde-pinha). Ex.: "Ver detalhes", "Ingressos".
- `.btn-ghost` — ação secundária (contorno). Ex.: "Falar no WhatsApp", "Ver no Instagram".
- `.btn-sm` — variante compacta, usada dentro dos cards.

### Badges / marcadores
- `.badge-type` — tipo do evento (Baile, Aula...), sobre a miniatura do card.
- `.pulse-today` — marcador "Hoje" com animação de pulso (`--clay`). Só aparece quando `ehHoje(evento)` é verdadeiro.
- `.chip` — marcador neutro dentro da página de evento (ex. "Música ao vivo").
- `.price-tag` — preço ou "Gratuito" no rodapé do card.
- **`.badge` + modificador** — sistema padronizado de badges informativas, usado na página de evento (`.badges-row`). Modificadores: `.badge--type` (tipo do evento), `.badge--free`, `.badge--ticket`, `.badge--couvert`, `.badge--local`, `.badge--list`, `.badge--esgotado` (forma de acesso — mapeados em `js/ingresso.js → badgeIngresso()`) e `.badge--live`, `.badge--dj` (tipo de música, incluindo o caso "Bandas e DJ" — usa `--live`). Nenhum modificador usa `--clay`: essa cor continua reservada só ao marcador "Hoje". O card de evento não usa mais badges — a forma de acesso (couvert, pagamento no local etc.) aparece direto na linha de valor (`.card-price`) quando relevante, mantendo o card enxuto.

### Banner "Hoje tem forró?"
- `.today-banner` — bloco de destaque na Home, logo abaixo do H1. Borda esquerda em `--clay` (mesma associação de "hoje" usada no resto do site). Três variações de conteúdo: data + contagem + cidades (há eventos), ou data + mensagem convidando para ver amanhã (não há eventos). Ver `criarBannerHoje()` em `js/components.js`.

### Cards
- `.event-card` — componente único de card de evento, usado na Home, na Agenda e nos "Eventos relacionados". Ver `js/components.js → criarEventCard(evento, contexto)`. Recebe `contexto.local` e `contexto.marca` para exibir endereço e identidade do baile — nunca busca esses dados sozinho.
- **Hierarquia visual do card** (inspirada em Sympla/Shotgun/Fever, adaptada à identidade do projeto): `.card-marca` (**Marca**, em destaque — texto grande, é o que fideliza) → `.card-evento-titulo` (Nome do evento, secundário) → `.card-line` (Data/Horário) → `.card-line--muted` (Cidade/Local) → `.card-price` (Valor, via `formatarValorIngresso()`) → botão "Ingressos" — este último só aparece quando o evento tem link de compra (`js/ingresso.js → botaoIngresso()`). Sem ingresso, o card continua navegável pela imagem e pelos títulos; só o botão extra some, sem deixar espaço vazio.
- A miniatura ocupa `aspect-ratio: 4/3` — proporcionalmente maior que o padrão anterior, para que a imagem tenha peso visual sem competir com a informação, que é o que decide se a pessoa vai ao evento.
- `.skeleton-card` — estado de carregamento, mesma altura/proporção do card real (evita salto de layout).
- `.empty-state` / `.empty-state-actions` — estado vazio, **nunca sem uma saída**: `criarEstadoVazio(titulo, mensagem, acoes)` aceita uma lista de ações (links ou botões com `onClick`, ex. "Limpar filtros", "Ver o mês inteiro").

### Grades de eventos
- `.event-grid` (base, até 3 colunas) — Home e "Eventos relacionados": listas curadas e curtas.
- **`.event-grid.is-grade`** (até 4 colunas em telas largas) — visualização padrão da Agenda. Grade contínua sem agrupamento por dia: cada card já mostra a data, e a comparação lado a lado é o objetivo (descoberta, não consulta de calendário).

### Formulários / filtros
- `.filter-select` — `<select>` estilizado, usado nos filtros da Agenda. Base para futuros campos de formulário (ex. formulário de organizador na Etapa 4).
- `.search-input` — campo de busca de texto livre. Mesma linguagem visual do `.filter-select`, largura total.
- **`.filters-panel-wrap`** — painel recolhível dos filtros avançados (cidade, tipo, entrada, horário, marca, formato). Fechado por padrão; abre com animação via `grid-template-rows: 0fr → 1fr` (não precisa medir altura em JS, e herda `prefers-reduced-motion` de graça, porque a regra global `*` em `tokens.css` já cobre qualquer `transition`). `.filtros-toggle` mostra a contagem de filtros ativos (`.filtros-count`) e usa `inert` no conteúdo enquanto fechado, pra não deixar `<select>` alcançável por Tab escondido. Abre sozinho se a URL já chega com filtro ativo.
- `.date-tabs` — tabs de período (Hoje/Amanhã/Semana/Mês), com `role="tablist"`/`aria-selected` para acessibilidade. Fica oculta (`hidden`) quando a visualização "Semana" está ativa, já que ela cobre sempre os próximos 7 dias.
- `.view-toggle` — par de botões "Grade"/"Semana" (`role="group"`, `aria-pressed`), controla o modo de exibição da Agenda.

### Grade semanal
- `.week-grid` / `.week-day` / `.week-event` — visualização em 7 colunas (uma por dia, a partir de hoje). Rolagem horizontal com snap no mobile, grade fixa a partir de 900px. `.week-day.is-today` destaca o dia atual com a cor `--clay` — mesma lógica do marcador "Hoje" nos cards, mantendo o terracota reservado a esse único significado em todo o site.

### Layout
- `.wrap` — container centralizado com largura máxima (`--container-max: 1120px`).
- `.section` / `.section-head` — bloco de seção genérico com título e eyebrow opcional.
- `.info-card` — card de informações práticas na página de evento (data, local, endereço, ações).

### Página de perfil (Marca — modelo para Professor/Banda no futuro)
- `.marca-banner` / `.marca-banner-overlay` / `.marca-banner-content` — título e logo vivem **dentro** do banner, sobre um gradiente escuro (`rgba(0,0,0,.7) → transparent`) que garante legibilidade independente de quão clara a foto de capa seja. Nunca mais depende de "sorte" com a cor da imagem.
- `.marca-logo` — fallback de iniciais sobre gradiente verde-pinha quando não há imagem.
- `.marca-subheader` — cidade, frequência, "desde" e links, no fundo normal da página, abaixo do banner. **O local físico não faz parte da identidade da Marca** — uma marca pode trocar de casa e continuar sendo a mesma marca; o local mora no evento (`local`/`localSlug`), nunca no cabeçalho da Marca.
- `.history-list` / `.history-item` — lista leve de eventos passados ("Últimos eventos"), deliberadamente mais simples que `.event-card`: o objetivo aqui é transmitir "isso existe há anos", não vender o próximo evento.
- **`.future-feature` / `criarFuturoRecurso()`** — espaço reservado para funcionalidades futuras (avaliações, seguidores, estatísticas). Nunca mostra número ou dado inventado — só um rótulo "Em breve" e uma frase explicando o que vai aparecer ali. Reutilizável em qualquer página de perfil.
- `.eyebrow` (standalone, fora de `.section-head`) — rótulo de Marca acima de título, em `--pine`.

### Página de evento — ordem das seções
Descrição → informações práticas + ações (ingresso, mapa, contato, compartilhar) → **Eventos relacionados por último**, sempre, em qualquer largura de tela. "Relacionados" fica fora do grid de duas colunas (`.event-detail-grid`) de propósito: dentro dele, a ordem no DOM vira a ordem visual no mobile quando as colunas empilham, e sugerir outro evento antes da pessoa terminar de decidir sobre o atual atrapalha a conversão — mesmo padrão de Sympla/Ticketmaster/Eventbrite.

### Home — arquitetura de blocos
A Home não é mais uma página monolítica: `js/home.js` mantém uma lista ordenada de funções (`criarBlocoHero`, `criarBlocoHojeTemForro`, `criarBlocoMiniCalendario`, `criarBlocoProximosEventos`, `criarBlocoDescubraMarca`, `criarBlocoSobre`, `criarBlocoTagline`), cada uma devolvendo um `<section>` pronto ou `null` quando não há o que mostrar. Adicionar, remover, reordenar ou trocar um bloco por uma versão personalizada (quando existir login) é editar essa lista — nunca reescrever a página. Um bloco que falha (`try/catch` no orquestrador) não derruba os demais. Todos os blocos vivem em `home.js` por enquanto; se a lista crescer bastante, o próximo passo natural é migrar cada função pra um arquivo em `js/home/` — refactor mecânico, não mudança de arquitetura.

- **Hero (carrossel)** — `.hero-carousel`, layout próprio (banner cheio, texto sobre gradiente), não é `.event-card`: mesma lógica de `.event-hero` já ter seu próprio tratamento visual na página de evento. Autoplay a cada 6s, pausa em hover/toque, retoma após interação manual (seta ou bolinha) — o controle nunca sai da mão do usuário. `.hero-slide-content` usa `min-width: 0` de propósito: sem isso, um item flex não encolhe abaixo da largura do próprio conteúdo, e título comprido vaza pra fora do card em telas estreitas em vez de quebrar linha.
- **"Hoje tem forró?"** — vem logo depois do Hero (antes do mini calendário: é a resposta mais direta que a Home dá). Mostra nomes de marcas (não só cidades) e tem CTA "Ver todos" pra `agenda.html?janela=hoje`.
- **Mini calendário semanal** — `.mini-week`, 7 dias com bolinha de intensidade (`.mini-week-dot.nivel-1/2/3`, por contagem de eventos). Cada dia é um link pra `agenda.html?view=semana` — reaproveita a visualização Semana que já existe, sem precisar de rota nova por dia específico.
- **Próximos eventos (carrossel horizontal)** — `.event-row`, scroll com snap, reaproveita `criarEventCard()` sem nenhuma variação nova.
- **Descubra uma Marca** — reaproveita `.about-band` (mesmo bloco de "Sobre o Movimento") e `.marca-logo` (mesmo componente da página de perfil). Marca sorteada entre as `ativo: true` a cada carregamento — sensação de descoberta sem precisar de um campo de curadoria manual.
- **Tagline de fechamento** — o `<h1>` do site ("Onde tem forró?") mora aqui, como o último bloco, não no topo. Quem entrou já sabe que quer forró; a primeira coisa que a pessoa vê é o Hero com eventos de verdade, não uma frase institucional.

### Espaçamento entre seções
`.section + .section { padding-top: 0; }` — seções adjacentes não somam o padding-bottom de uma com o padding-top da próxima (isso dobrava o respiro visual). A primeira seção de uma sequência mantém o espaço total; as seguintes contam só com o padding-bottom da anterior. Vale pra qualquer página com `.section`s em sequência (Home, Marca), não só onde o problema apareceu primeiro.

### Busca no header
`.header-search-toggle` (lupa) + `.header-search-panel` (mesma técnica de altura animável `grid-template-rows: 0fr → 1fr` do painel de filtros da Agenda) aparecem em toda página. `ligarBuscaHeader()` em `components.js` tem dois comportamentos, escolhidos automaticamente conforme o que existe na página: na própria Agenda, a lupa rola até o campo de busca que já é sempre visível ali (`#campo-busca`) — nunca abre um painel duplicado; nas demais páginas, abre um mini-painel cujo envio leva pra `agenda.html?busca=...`, a mesma busca de sempre (evento e marca), sem nenhuma lógica nova.

## Acessibilidade

- Todos os componentes interativos usam `:focus-visible` com contorno de 3px.
- `.sr-only` para texto only-leitor-de-tela (labels de filtro).
- `.skip-link` para pular direto ao conteúdo.
- Contraste de texto (`--ink` sobre `--paper`/`--surface`) segue WCAG AA.
- `prefers-reduced-motion` desativa animações (pulso do marcador "Hoje", shimmer do skeleton).

## O que ainda não existe (e onde vai entrar)

- **Listagem "todas as marcas"** — a página de perfil individual existe; falta uma página de navegação/descoberta entre marcas, quando fizer sentido priorizar.
- **Avaliações, seguidores, estatísticas** — espaços já reservados na página da Marca (`.future-feature`); dependem de login e de novas entidades que ainda não existem.
- **Estados de ingresso** (gratuito/couvert/pagamento local/lista/esgotado) — arquitetura pronta em `js/ingresso.js`, visual a definir quando os inativos forem implementados (só "antecipado" está ativo hoje).
- **Componentes de formulário completos** (input de texto, textarea, upload de imagem) — vêm com o painel administrativo.
- **Mapa interativo** — vai precisar de um token de altura padrão e um card de resultado próprio.
